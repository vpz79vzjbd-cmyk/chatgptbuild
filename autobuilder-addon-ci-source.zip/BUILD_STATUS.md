# Build status and requirements

This archive is the source project prepared for a remote Gradle build. It is **not** a compiled JAR.

## Verified locally

- Java 21 is installed in the current workspace.
- All four supplied dependency JARs pass ZIP integrity checks.
- Their embedded metadata targets Minecraft 1.21.11.
- The supplied Litematica and MaLiLib artifacts were built with Gradle 9.7.1 and Fabric Loom 1.17.20.
- Gradle 9.7.1 and Fabric Loom 1.17.20 release coordinates were checked against their official repositories.

## Build workflow

The workflow is located at `.github/workflows/build.yml` at the repository root. It provisions Java 21 and Gradle 9.7.1, validates the four supplied dependency JARs, runs `gradle clean build`, checks the produced JAR contains the addon entrypoint and `fabric.mod.json`, then uploads the JAR as the `autobuilder-addon-1.0.0` artifact.

## Why no JAR is attached yet

The current ChatGPT execution environment has no Gradle installation/cache and cannot resolve external hosts (`services.gradle.org` DNS lookup fails). The actual compilation therefore has to run in an online CI runner. No compiled artifact is claimed until that workflow succeeds.
