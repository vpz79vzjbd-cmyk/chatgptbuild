# AutoBuilder Easy Place — Minecraft 1.21.11

Meteor Client addon for Fabric 1.21.11. It adds the `easy-place` module under Meteor GUI → World.

## Supplied build dependencies

The four compatible dependency JARs are already included under `libs/`:

- Meteor Client 1.21.11 build 86
- Litematica 0.26.16
- MaLiLib 0.27.20
- Baritone API 1.17.0

## Build

The GitHub Actions workflow at `.github/workflows/build.yml` builds this project with Java 21 and Gradle 9.7.1. Push this project to the **root** of a GitHub repository, then open Actions and run **Build AutoBuilder Addon**. A successful run uploads the compiled JAR files as the artifact `autobuilder-addon-1.0.0`.

For a local build, install Gradle 9.7.1 and Java 21, then run:

```sh
gradle clean build --no-daemon --stacktrace
```

The remapped JAR (the file without the `-dev` suffix, if both are present) belongs in the Minecraft `mods/` folder alongside Meteor Client, Litematica, MaLiLib, and Baritone.

## Important

This source package is not itself a compiled JAR. A successful build must be confirmed by a completed CI run; do not treat a source ZIP as a finished mod.
