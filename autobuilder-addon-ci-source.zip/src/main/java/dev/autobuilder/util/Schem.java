package dev.autobuilder.util;

import fi.dy.masa.litematica.data.DataManager;
import fi.dy.masa.litematica.schematic.placement.SchematicPlacement;
import fi.dy.masa.litematica.selection.Box;
import fi.dy.masa.litematica.world.SchematicWorldHandler;
import fi.dy.masa.litematica.world.WorldSchematic;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

/**
 * Doc du lieu truc tiep tu Litematica.
 * WorldSchematic nam o toa do the gioi: rotation/mirror cua placement da duoc Litematica ap dung san.
 */
public final class Schem {
    private Schem() {}

    public static List<SchematicPlacement> active() {
        List<SchematicPlacement> out = new ArrayList<>();
        var mgr = DataManager.getSchematicPlacementManager();
        if (mgr == null) return out;
        for (SchematicPlacement p : mgr.getAllSchematicsPlacements()) if (p != null && p.isEnabled()) out.add(p);
        return out;
    }

    /** null neu doc duoc; nguoc lai tra ve thong bao loi. */
    public static String error() {
        try {
            if (active().isEmpty()) return "Không có schematic placement nào đang bật trong Litematica.";
            WorldSchematic w = SchematicWorldHandler.getSchematicWorld();
            if (w == null) return "Không đọc được schematic world của Litematica (chưa load schematic?).";
            return null;
        } catch (Throwable t) {
            return "Không đọc được schematic: " + t;
        }
    }

    /** BlockState mong muon tai toa do the gioi, hoac null neu ngoai moi schematic. */
    public static BlockState wanted(BlockPos pos) {
        WorldSchematic w = SchematicWorldHandler.getSchematicWorld();
        if (w == null || !inside(pos)) return null;
        return w.getBlockState(pos);
    }

    public static boolean inside(BlockPos pos) {
        for (SchematicPlacement p : active()) {
            Box b = p.getEclosingBox();
            if (b == null || b.getPos1() == null || b.getPos2() == null) continue;
            BlockPos a = b.getPos1(), c = b.getPos2();
            if (pos.getX() >= Math.min(a.getX(), c.getX()) && pos.getX() <= Math.max(a.getX(), c.getX())
                && pos.getY() >= Math.min(a.getY(), c.getY()) && pos.getY() <= Math.max(a.getY(), c.getY())
                && pos.getZ() >= Math.min(a.getZ(), c.getZ()) && pos.getZ() <= Math.max(a.getZ(), c.getZ())) return true;
        }
        return false;
    }

    /** {minX,minY,minZ,maxX,maxY,maxZ} hop cua moi placement dang bat, hoac null. */
    public static int[] bounds() {
        int[] r = null;
        for (SchematicPlacement p : active()) {
            Box b = p.getEclosingBox();
            if (b == null || b.getPos1() == null || b.getPos2() == null) continue;
            BlockPos a = b.getPos1(), c = b.getPos2();
            int[] n = {Math.min(a.getX(), c.getX()), Math.min(a.getY(), c.getY()), Math.min(a.getZ(), c.getZ()),
                Math.max(a.getX(), c.getX()), Math.max(a.getY(), c.getY()), Math.max(a.getZ(), c.getZ())};
            if (r == null) r = n;
            else for (int i = 0; i < 3; i++) { r[i] = Math.min(r[i], n[i]); r[i + 3] = Math.max(r[i + 3], n[i + 3]); }
        }
        return r;
    }
}
