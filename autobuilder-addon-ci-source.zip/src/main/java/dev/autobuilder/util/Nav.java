package dev.autobuilder.util;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.pathing.goals.Goal;
import baritone.api.pathing.goals.GoalNear;
import net.minecraft.util.math.BlockPos;

/** Cau noi toi Baritone API (khong dung BuilderProcess cua Baritone de tranh dat sai huong). */
public final class Nav {
    private static Goal ours;
    private static String lastError;

    private Nav() {}

    private static IBaritone b() {
        try {
            return BaritoneAPI.getProvider().getPrimaryBaritone();
        } catch (Throwable t) {
            lastError = String.valueOf(t);
            return null;
        }
    }

    public static boolean available() { return b() != null; }

    public static String lastError() { return lastError; }

    /** Baritone dang chay mot muc tieu khong phai cua ta. */
    public static boolean busyWithOther() {
        IBaritone b = b();
        if (b == null) return false;
        try {
            boolean pathing = b.getPathingBehavior().isPathing() || b.getBuilderProcess().isActive();
            return pathing && (ours == null || b.getCustomGoalProcess().getGoal() != ours);
        } catch (Throwable t) { return false; }
    }

    public static boolean goNear(BlockPos pos, int range) {
        IBaritone b = b();
        if (b == null) return false;
        try {
            if (busyWithOther()) return false;
            ours = new GoalNear(pos, Math.max(0, range));
            b.getCustomGoalProcess().setGoalAndPath(ours);
            return true;
        } catch (Throwable t) {
            lastError = String.valueOf(t);
            return false;
        }
    }

    public static boolean isPathing() {
        IBaritone b = b();
        if (b == null) return false;
        try {
            return b.getPathingBehavior().isPathing() && ours != null && b.getCustomGoalProcess().getGoal() == ours;
        } catch (Throwable t) { return false; }
    }

    /** Chi huy Baritone neu muc tieu hien tai la cua ta. */
    public static void cancelOurs() {
        IBaritone b = b();
        if (b == null || ours == null) return;
        try {
            if (b.getCustomGoalProcess().getGoal() == ours) b.getPathingBehavior().cancelEverything();
        } catch (Throwable ignored) {}
        ours = null;
    }
}
