package dev.autobuilder.util;

import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.SlotUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.block.BlockState;

public final class Inv {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private Inv() {}

    /** So luong item (hotbar 0-8, hoac ca tui do 0-35). */
    public static int count(Item item, boolean fullInventory) {
        PlayerInventory inv = mc.player.getInventory();
        int n = 0;
        for (int i = 0; i < (fullInventory ? 36 : 9); i++) {
            ItemStack s = inv.getStack(i);
            if (s.getItem() == item) n += s.getCount();
        }
        return n;
    }

    public static boolean hasRoomFor(Item item) {
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) return true;
            if (s.getItem() == item && s.getCount() < s.getMaxCount()) return true;
        }
        return false;
    }

    public static boolean holding(Item item) {
        return mc.player.getMainHandStack().getItem() == item;
    }

    /**
     * Dua item vao tay chinh. Tra ve: 0 = da san sang (dang cam), 1 = vua doi slot (can cho dong bo), -1 = khong co.
     */
    public static int equip(Item item, boolean fullInventory) {
        if (holding(item)) return 0;
        FindItemResult r = fullInventory ? InvUtils.find(item) : InvUtils.findInHotbar(item);
        if (!r.found()) return -1;
        return moveToHand(r);
    }

    private static int moveToHand(FindItemResult r) {
        if (r.isHotbar()) {
            InvUtils.swap(r.slot(), false);
            return 1;
        }
        int hb = mc.player.getInventory().getSelectedSlot();
        InvUtils.quickSwap().fromId(hb).to(r.slot());
        return 1;
    }

    /** Chon cong cu pha block theo uu tien. mode: 0 = BestAvailable, 1 = HotbarOnly, 2 = LowestTier. */
    public static int equipTool(BlockState state, int mode, boolean noSilkTouch) {
        FindItemResult best = null;
        double bestScore = mode == 2 ? Double.MAX_VALUE : -1;
        int max = mode == 1 ? 9 : 36;
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < max; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) continue;
            if (noSilkTouch && hasSilk(s)) continue;
            float speed = s.getMiningSpeedMultiplier(state);
            if (speed <= 1.0f) continue;
            if (mode == 2) {
                if (speed < bestScore) { bestScore = speed; best = new FindItemResult(i, s.getCount()); }
            } else if (speed > bestScore) { bestScore = speed; best = new FindItemResult(i, s.getCount()); }
        }
        if (best == null) {
            // khong co cong cu tot hon tay khong: dung tay khong / slot khong silk
            for (int i = 0; i < 9; i++) {
                ItemStack s = inv.getStack(i);
                if (s.isEmpty() || !hasSilk(s) && !s.isDamageable()) {
                    if (inv.getSelectedSlot() != i) InvUtils.swap(i, false);
                    return 0;
                }
            }
            return 0;
        }
        if (inv.getSelectedSlot() == best.slot() && best.isHotbar()) return 0;
        return moveToHand(best);
    }

    public static boolean hasSilk(ItemStack s) {
        return s.getEnchantments().getEnchantments().stream().anyMatch(e -> e.matchesKey(Enchantments.SILK_TOUCH));
    }
}
