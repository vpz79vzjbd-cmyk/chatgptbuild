package dev.autobuilder.util;

import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.MovingPistonBlock;
import net.minecraft.block.PistonHeadBlock;
import net.minecraft.block.enums.BedPart;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;

import java.util.Set;

public final class StateUtil {
    private StateUtil() {}

    /** Property dong (phu thuoc redstone / tuong tac), khong the quyet dinh luc dat block. */
    private static final Set<String> DYNAMIC = Set.of("powered", "lit", "open", "waterlogged", "triggered",
        "extended", "power", "enabled", "locked", "delay", "distance", "persistent", "signal_fire", "attached",
        "inverted", "has_book", "has_record", "bloom", "shrieking", "can_summon", "berries");

    /** strict=true: so sanh moi property tinh; strict=false: chi so sanh block. */
    public static boolean matches(BlockState actual, BlockState wanted, boolean strict) {
        if (actual == null || wanted == null) return false;
        if (actual.getBlock() != wanted.getBlock()) return false;
        if (!strict) return true;
        for (Property<?> p : wanted.getProperties()) {
            if (DYNAMIC.contains(p.getName())) continue;
            if (!actual.contains(p)) return false;
            if (!actual.get(p).equals(wanted.get(p))) return false;
        }
        return true;
    }

    /** Nua phu thuoc: duoc tao ra khi dat nua chinh (cua tren, dau giuong, dau piston). */
    public static boolean isDependentHalf(BlockState s) {
        Block b = s.getBlock();
        if (b instanceof PistonHeadBlock || b instanceof MovingPistonBlock) return true;
        if (b instanceof BedBlock && s.contains(BedBlock.PART) && s.get(BedBlock.PART) == BedPart.HEAD) return true;
        return s.contains(Properties.DOUBLE_BLOCK_HALF) && s.get(Properties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.UPPER;
    }

    public static boolean isDirectional(BlockState s) {
        for (Property<?> p : s.getProperties()) {
            String n = p.getName();
            if (n.equals("facing") || n.equals("axis") || n.equals("rotation") || n.equals("half") || n.equals("shape")
                || n.equals("hinge") || n.equals("orientation") || n.equals("type") || n.equals("face")) return true;
        }
        return false;
    }
}
