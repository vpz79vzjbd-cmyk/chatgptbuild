package dev.autobuilder.util;

import meteordevelopment.meteorclient.utils.world.BlockUtils;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.block.ShapeContext;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

/**
 * Khong hardcode huong. Voi moi to hop (block de click, mat, diem cham, yaw/pitch) ta hoi chinh Minecraft
 * Block#getPlacementState(ItemPlacementContext) se ra BlockState nao, roi chon to hop cho ra dung BlockState schematic.
 */
public final class Solver {
    private Solver() {}

    public record Plan(BlockPos neighbor, Direction face, Vec3d hit, float yaw, float pitch) {}

    private static final float[] YAWS = {0f, 90f, 180f, -90f};
    private static final float[] PITCHES = {0f, 90f, -90f};
    private static final double[] OFFS = {0.0, -0.25, 0.25};

    public static Plan solve(MinecraftClient mc, BlockPos pos, BlockState want, ItemStack stack,
                             Predicate<BlockState> acceptable, boolean allowRotations, boolean smart, double reach) {
        ClientPlayerEntity p = mc.player;
        World w = mc.world;
        if (p == null || w == null) return null;

        float oy = p.getYaw(), op = p.getPitch();
        List<float[]> rots = new ArrayList<>();
        rots.add(new float[]{oy, op});
        if (allowRotations) {
            for (float y : YAWS) for (float pt : PITCHES) rots.add(new float[]{y, pt});
            // uu tien xoay it nhat (giu nguyen cai dau tien = huong hien tai)
            List<float[]> rest = new ArrayList<>(rots.subList(1, rots.size()));
            rest.sort(Comparator.comparingDouble(r -> Math.abs(wrap(r[0] - oy)) + Math.abs(r[1] - op)));
            rots = new ArrayList<>();
            rots.add(new float[]{oy, op});
            rots.addAll(rest);
        }

        Vec3d eye = p.getEyePos();
        int usedFaces = 0;
        try {
            for (Direction dir : Direction.values()) {
                BlockPos n = pos.offset(dir);
                BlockState ns = w.getBlockState(n);
                if (ns.isAir() || ns.getOutlineShape(w, n).isEmpty()) continue;
                if (!ns.getFluidState().isEmpty() && ns.getCollisionShape(w, n).isEmpty()) continue;
                if (BlockUtils.isClickable(ns.getBlock())) continue; // click vao se mo GUI
                if (!smart && usedFaces >= 1) break;
                usedFaces++;

                Direction face = dir.getOpposite();
                for (double o1 : OFFS) {
                    for (double o2 : OFFS) {
                        Vec3d hit = faceHit(n, face, o1, o2);
                        if (eye.distanceTo(hit) > reach) continue;
                        BlockHitResult hr = new BlockHitResult(hit, face, n, false);
                        for (float[] r : rots) {
                            p.setYaw(r[0]);
                            p.setPitch(r[1]);
                            ItemPlacementContext ctx = new ItemPlacementContext(w, p, Hand.MAIN_HAND, stack, hr);
                            if (!w.getBlockState(pos).canReplace(ctx)) break;
                            BlockState got = want.getBlock().getPlacementState(ctx);
                            if (got == null || !acceptable.test(got)) continue;
                            if (!got.canPlaceAt(w, pos)) continue;
                            if (!w.canPlace(got, pos, ShapeContext.of(p))) continue;
                            return new Plan(n, face, hit, r[0], r[1]);
                        }
                    }
                }
            }
        } finally {
            p.setYaw(oy);
            p.setPitch(op);
        }
        return null;
    }

    private static float wrap(float a) {
        a %= 360f;
        if (a > 180f) a -= 360f;
        if (a < -180f) a += 360f;
        return a;
    }

    private static Vec3d faceHit(BlockPos n, Direction face, double o1, double o2) {
        Vec3d c = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
        return switch (face.getAxis()) {
            case X -> c.add(0, o1, o2);
            case Y -> c.add(o1, 0, o2);
            case Z -> c.add(o1, o2, 0);
        };
    }
}
