package dev.autobuilder.util;

import net.minecraft.block.ChestBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

/**
 * May trang thai: GOTO -> OPEN -> WAIT_GUI -> TAKE -> VERIFY -> (RETURN). Moi buoc deu kiem tra thanh cong that su,
 * khong gia lap viec lay do.
 */
public final class ChestSupply {
    private enum Stage { IDLE, GOTO, OPEN, WAIT_GUI, VERIFY, RETURN }

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final Consumer<String> err;
    private final Consumer<String> info;

    private Stage stage = Stage.IDLE;
    private Item item;
    private int need;
    private BlockPos home;          // cho dung truoc khi di lay do
    private List<BlockPos> chests = new ArrayList<>();
    private int chestIdx;
    private int timer;
    private int before;
    private int taken;
    private boolean returnToBuilding;
    private boolean useBaritone;
    private int lastResult;         // 0 = chua co, 1 = thanh cong, -1 = that bai

    public ChestSupply(Consumer<String> err, Consumer<String> info) {
        this.err = err;
        this.info = info;
    }

    public boolean active() { return stage != Stage.IDLE; }

    public Item item() { return item; }

    /** Ket qua cua lan lay gan nhat: 1 = lay duoc, -1 = that bai. Doc xong thi reset. */
    public int consumeResult() { int r = lastResult; lastResult = 0; return r; }

    public static List<BlockPos> findChests(MinecraftClient mc, BlockPos center, int radius) {
        List<BlockPos> out = new ArrayList<>();
        if (mc.world.getBlockState(center).getBlock() instanceof ChestBlock) out.add(center);
        if (radius > 0) {
            BlockPos.Mutable m = new BlockPos.Mutable();
            for (int x = -radius; x <= radius; x++)
                for (int y = -radius; y <= radius; y++)
                    for (int z = -radius; z <= radius; z++) {
                        m.set(center.getX() + x, center.getY() + y, center.getZ() + z);
                        if (m.equals(center)) continue;
                        if (mc.world.getBlockState(m).getBlock() instanceof ChestBlock) out.add(m.toImmutable());
                    }
            out.sort(Comparator.comparingDouble(p -> p.getSquaredDistance(center)));
        }
        return out;
    }

    public boolean start(Item item, int need, BlockPos chestPos, int radius, boolean returnToBuilding, boolean useBaritone) {
        if (active()) return true;
        this.chests = findChests(mc, chestPos, radius);
        if (chests.isEmpty()) {
            err.accept("Không tìm thấy rương tại " + chestPos.toShortString() + " (cũng không có rương nào trong bán kính " + radius + "). Hãy kiểm tra tọa độ / chunk đã load chưa.");
            lastResult = -1;
            return false;
        }
        this.item = item;
        this.need = Math.max(1, need);
        this.home = mc.player.getBlockPos();
        this.returnToBuilding = returnToBuilding;
        this.useBaritone = useBaritone;
        this.chestIdx = 0;
        this.taken = 0;
        this.stage = Stage.GOTO;
        this.timer = 0;
        info.accept("Thiếu " + item.getName().getString() + ", đi lấy từ rương " + chests.get(0).toShortString());
        return true;
    }

    public void abort() {
        if (mc.player != null && mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) mc.player.closeHandledScreen();
        if (stage != Stage.IDLE) Nav.cancelOurs();
        stage = Stage.IDLE;
    }

    private void fail(String msg) {
        err.accept(msg);
        lastResult = -1;
        if (mc.player != null && mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) mc.player.closeHandledScreen();
        stage = Stage.IDLE;
    }

    private void nextChestOrFail(String reason) {
        if (mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) mc.player.closeHandledScreen();
        chestIdx++;
        if (chestIdx < chests.size() && taken < need) {
            info.accept(reason + " Thử rương tiếp theo " + chests.get(chestIdx).toShortString());
            stage = Stage.GOTO;
            timer = 0;
        } else if (taken > 0) {
            finish();
        } else {
            fail("Không rương nào chứa " + item.getName().getString() + ". " + reason);
        }
    }

    private void finish() {
        lastResult = 1;
        if (returnToBuilding && useBaritone && mc.player.getBlockPos().getSquaredDistance(home) > 4) {
            if (Nav.goNear(home, 1)) { stage = Stage.RETURN; timer = 0; return; }
        }
        stage = Stage.IDLE;
    }

    /** Goi moi tick khi active(). */
    public void tick() {
        if (stage == Stage.IDLE) return;
        if (mc.player == null || mc.world == null) { stage = Stage.IDLE; return; }
        timer++;
        BlockPos cp = chests.get(Math.min(chestIdx, chests.size() - 1));

        switch (stage) {
            case GOTO -> {
                if (!(mc.world.getBlockState(cp).getBlock() instanceof ChestBlock)) {
                    nextChestOrFail("Rương " + cp.toShortString() + " không còn tồn tại.");
                    return;
                }
                double d = mc.player.getEyePos().distanceTo(Vec3d.ofCenter(cp));
                if (d <= 4.4) { Nav.cancelOurs(); stage = Stage.OPEN; timer = 0; return; }
                if (!useBaritone) { fail("Rương ở xa (" + (int) d + " block) và Baritone bị tắt."); return; }
                if (timer == 1 || (!Nav.isPathing() && timer % 40 == 0)) {
                    if (Nav.busyWithOther()) { fail("Baritone đang chạy tác vụ khác, không thể di chuyển tới rương."); return; }
                    if (!Nav.goNear(cp, 3)) { fail("Không điều khiển được Baritone: " + Nav.lastError()); return; }
                }
                if (timer > 20 * 60) fail("Baritone không tìm được đường tới rương " + cp.toShortString() + " (quá thời gian).");
                else if (timer > 60 && !Nav.isPathing() && d > 4.4) fail("Baritone không tìm được đường tới rương " + cp.toShortString() + ".");
            }
            case OPEN -> {
                if (mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) { stage = Stage.WAIT_GUI; timer = 0; return; }
                if (timer % 10 == 1) {
                    BlockHitResult hr = new BlockHitResult(Vec3d.ofCenter(cp), Direction.UP, cp, false);
                    mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hr);
                    mc.player.swingHand(Hand.MAIN_HAND);
                }
                if (mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) { stage = Stage.WAIT_GUI; timer = 0; }
                else if (timer > 60) nextChestOrFail("Không mở được rương " + cp.toShortString() + " (bị chặn hoặc server từ chối).");
            }
            case WAIT_GUI -> {
                if (!(mc.player.currentScreenHandler instanceof GenericContainerScreenHandler h)) {
                    if (timer > 40) nextChestOrFail("Giao diện rương đóng bất ngờ.");
                    return;
                }
                if (timer < 3) return; // doi server gui noi dung
                int chestSlots = h.getRows() * 9;
                before = Inv.count(item, true);
                int want = need - taken;
                int moved = 0;
                if (!Inv.hasRoomFor(item)) { fail("Inventory đầy, không thể lấy " + item.getName().getString() + "."); return; }
                for (int i = 0; i < chestSlots && moved < want; i++) {
                    ItemStack s = h.getSlot(i).getStack();
                    if (s.isEmpty() || s.getItem() != item) continue; // chi lay dung vat lieu can thiet
                    mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
                    moved += s.getCount();
                }
                if (moved == 0) { nextChestOrFail("Rương " + cp.toShortString() + " không có " + item.getName().getString() + "."); return; }
                taken += moved;
                stage = Stage.VERIFY;
                timer = 0;
            }
            case VERIFY -> {
                if (timer < 6) return;
                int now = Inv.count(item, true);
                if (mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) mc.player.closeHandledScreen();
                if (now <= before) {
                    taken = 0;
                    nextChestOrFail("Lấy " + item.getName().getString() + " không thành công (server từ chối / inventory đầy).");
                    return;
                }
                taken = now - before;
                info.accept("Đã lấy " + taken + "x " + item.getName().getString() + " từ rương.");
                if (taken < need && chestIdx + 1 < chests.size()) { nextChestOrFail("Chưa đủ (" + taken + "/" + need + ")."); return; }
                finish();
            }
            case RETURN -> {
                if (mc.player.getBlockPos().getSquaredDistance(home) <= 4) { Nav.cancelOurs(); stage = Stage.IDLE; return; }
                if (timer > 20 * 60 || (timer > 60 && !Nav.isPathing())) {
                    Nav.cancelOurs();
                    err.accept("Không quay lại được vị trí xây dựng " + home.toShortString() + ".");
                    stage = Stage.IDLE;
                }
            }
            default -> {}
        }
    }
}
