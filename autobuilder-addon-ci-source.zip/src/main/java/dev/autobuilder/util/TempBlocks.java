package dev.autobuilder.util;

import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Chi theo doi va thu hoi chinh xac cac block tam do module nay dat. */
public final class TempBlocks {
    public enum Pref { Stone, Glass, Auto }

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final Set<BlockPos> placed = new LinkedHashSet<>();

    public int size() { return placed.size(); }

    public boolean owns(BlockPos p) { return placed.contains(p); }

    public void clear() { placed.clear(); }

    /** Chon item block tam theo setting va hang ton. Tra ve null neu khong co ca hai. */
    public Item pick(Pref pref, boolean fullInv) {
        Item first = pref == Pref.Glass ? Items.GLASS : Items.STONE;
        Item second = pref == Pref.Auto ? Items.GLASS : null;
        if (Inv.count(first, fullInv) > 0) return first;
        if (second != null && Inv.count(second, fullInv) > 0) return second;
        return null;
    }

    /** Ung vien thu nhat can lay tu ruong khi het ca hai. */
    public Item preferred(Pref pref) { return pref == Pref.Glass ? Items.GLASS : Items.STONE; }

    /** Duoc phep dat block tam tai pos? (khong de len schematic, khong de len block co san) */
    public boolean valid(BlockPos pos) {
        BlockState cur = mc.world.getBlockState(pos);
        if (!cur.isReplaceable() || !cur.getFluidState().isEmpty()) return false;
        BlockState want = Schem.wanted(pos);
        return want == null || want.isAir();
    }

    /** Dat 1 block tam o pos (da chon san trong tay/hotbar). */
    public boolean place(BlockPos pos, Item item) {
        if (!valid(pos)) return false;
        if (!Inv.holding(item)) return false;
        boolean ok = BlockUtils.place(pos, InvUtils.findInHotbar(item), true, 40);
        if (ok) placed.add(pos.toImmutable());
        return ok;
    }

    /** Vi tri ban chan de dap them (bridge) ve phia target; null neu khong co cho hop le. */
    public BlockPos bridgeStep(BlockPos target) {
        BlockPos feet = mc.player.getBlockPos();
        int dx = Integer.signum(target.getX() - feet.getX());
        int dz = Integer.signum(target.getZ() - feet.getZ());
        Direction d = Math.abs(target.getX() - feet.getX()) >= Math.abs(target.getZ() - feet.getZ())
            ? (dx > 0 ? Direction.EAST : Direction.WEST) : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
        BlockPos p = feet.down().offset(d);
        return valid(p) ? p : null;
    }

    /** Vi tri dap len tren dau (pillar). */
    public BlockPos pillarSpot() {
        BlockPos p = mc.player.getBlockPos().down();
        return valid(p) ? p : null;
    }

    /** Thu hoi moi block tam trong tam voi: pha tu tren xuong. Tra ve so con lai (can goi lai moi tick). */
    public int cleanupStep() {
        if (placed.isEmpty()) return 0;
        List<BlockPos> list = new ArrayList<>(placed);
        list.sort(Comparator.comparingInt((BlockPos p) -> -p.getY()));
        for (BlockPos p : list) {
            BlockState s = mc.world.getBlockState(p);
            if (s.isAir() || s.getBlock().asItem() != Items.STONE && s.getBlock().asItem() != Items.GLASS) {
                placed.remove(p); // da bi go / thay the, khong con la block tam cua ta
                continue;
            }
            if (Schem.wanted(p) != null && !Schem.wanted(p).isAir()) { placed.remove(p); continue; } // gio la block cua cong trinh
            if (mc.player.getEyePos().distanceTo(net.minecraft.util.math.Vec3d.ofCenter(p)) > 4.5) continue;
            Inv.equipTool(s, 0, false);
            BlockUtils.breakBlock(p, true);
            return placed.size();
        }
        return placed.size();
    }
}
