package dev.autobuilder.modules;

import dev.autobuilder.util.ChestSupply;
import dev.autobuilder.util.Inv;
import dev.autobuilder.util.Nav;
import dev.autobuilder.util.Schem;
import dev.autobuilder.util.Solver;
import dev.autobuilder.util.StateUtil;
import dev.autobuilder.util.TempBlocks;
import meteordevelopment.meteorclient.events.entity.player.InteractBlockEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockPosSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HopperBlock;
import net.minecraft.block.FluidBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class EasyPlace extends Module {
    public enum PickSource { VisibleOnly, FullInventory }
    public enum PickSync { ServerAck, Instant }
    public enum DepSync { Immediate, NextTick }
    public enum Direction { Auto, KeepLook }
    public enum PickPrio { BestAvailable, HotbarOnly, LowestTier }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgChest = settings.createGroup("Chest Supply");
    private final SettingGroup sgTemp = settings.createGroup("Temporary Blocks");
    private final SettingGroup sgWater = settings.createGroup("Auto Water");
    private final SettingGroup sgRepair = settings.createGroup("Wrong Block Repair");

    // ---- General ----
    private final Setting<Boolean> allBlocks = bool(sgGeneral, "all-blocks", "Áp dụng cho mọi block. Tắt: chỉ block có thuộc tính hướng (facing/axis/half/...).", true);
    private final Setting<Boolean> showStatus = bool(sgGeneral, "show-status-message", "Hiện trạng thái xây dựng trên thanh overlay.", true);
    private final Setting<Boolean> rotationSpoof = bool(sgGeneral, "rotation-spoof", "Gửi yaw/pitch tới server để block ra đúng hướng schematic (không phụ thuộc hướng nhìn thật).", true);
    private final Setting<Direction> direction = sgGeneral.add(new EnumSetting.Builder<Direction>().name("direction")
        .description("Auto: tự tìm hướng nhìn + mặt click cho ra đúng BlockState. KeepLook: chỉ dùng hướng nhìn hiện tại.")
        .defaultValue(Direction.Auto).build());
    private final Setting<Boolean> smartPlacement = bool(sgGeneral, "smart-placement", "Thử mọi mặt block kề. Tắt: chỉ thử mặt khả dụng đầu tiên.", true);
    private final Setting<PickSource> pickSource = sgGeneral.add(new EnumSetting.Builder<PickSource>().name("inventory-pick-source")
        .description("VisibleOnly: chỉ hotbar. FullInventory: cả túi đồ (tự chuyển vào hotbar).")
        .defaultValue(PickSource.VisibleOnly).build());
    private final Setting<PickSync> pickSync = sgGeneral.add(new EnumSetting.Builder<PickSync>().name("inventory-pick-sync")
        .description("ServerAck: sau khi đổi slot chờ 1 tick + ping trước khi đặt. Instant: đặt ngay.")
        .defaultValue(PickSync.ServerAck).build());
    private final Setting<DepSync> depSync = sgGeneral.add(new EnumSetting.Builder<DepSync>().name("dependency-sync")
        .description("Immediate: đặt block phụ thuộc ngay trong cùng tick (dựa vào dự đoán client). NextTick: chờ 1 tick giữa các block.")
        .defaultValue(DepSync.Immediate).build());
    private final Setting<Boolean> schematicOnly = bool(sgGeneral, "schematic-only", "Chỉ xử lý vị trí thuộc schematic; ngoài schematic dùng đặt block vanilla.", true);
    private final Setting<Boolean> schematicLock = bool(sgGeneral, "schematic-lock", "Chặn đặt thủ công sai block/sai hướng trong vùng schematic.", false);
    private final Setting<Boolean> aura = bool(sgGeneral, "schematic-aura", "Tự động đặt block theo schematic trong tầm (công tắc chính của auto build).", true);
    private final Setting<Double> auraRange = sgGeneral.add(new DoubleSetting.Builder().name("aura-range").description("Tầm đặt block (block).")
        .defaultValue(4.5).range(1, 6).sliderRange(1, 6).build());
    private final Setting<Integer> auraDelay = sgGeneral.add(new IntSetting.Builder().name("aura-delay").description("Số tick giữa hai lần đặt.")
        .defaultValue(1).range(0, 20).sliderRange(0, 20).build());
    private final Setting<Boolean> hopperForce = bool(sgGeneral, "hopper-force-facing", "Hopper phải đúng hướng schematic. Tắt: chấp nhận hopper hướng bất kỳ.", true);
    private final Setting<Boolean> hopperHidden = bool(sgGeneral, "hopper-force-when-hidden", "Vẫn ép hướng hopper khi vị trí hopper không nằm trong tầm nhìn thẳng.", true);
    private final Setting<Boolean> chatFb = bool(sgGeneral, "chat-feedback", "Gửi thông báo tiến trình/lỗi vào chat.", true);
    private final Setting<Boolean> baritoneMove = bool(sgGeneral, "baritone-move", "Dùng Baritone để tự di chuyển tới vùng cần xây / rương.", true);
    private final Setting<Boolean> strictState = bool(sgGeneral, "schematic-blockstate-verification", "So sánh toàn bộ BlockState (không chỉ tên block) khi đặt và kiểm tra.", true);

    // ---- Chest ----
    private final Setting<Boolean> chestEnable = bool(sgChest, "enable-chest-supply", "Lấy vật liệu từ rương khi thiếu.", false);
    private final Setting<BlockPos> chestPos = sgChest.add(new BlockPosSetting.Builder().name("chest-pos").description("Tọa độ X Y Z của rương vật liệu.")
        .defaultValue(BlockPos.ORIGIN).build());
    private final Setting<Boolean> autoRefill = bool(sgChest, "auto-refill", "Tự bổ sung khi số lượng xuống dưới ngưỡng.", true);
    private final Setting<Integer> chestRadius = sgChest.add(new IntSetting.Builder().name("chest-search-radius")
        .description("Bán kính tìm thêm rương khác quanh tọa độ đã nhập (0 = chỉ rương đã nhập).")
        .defaultValue(0).range(0, 16).sliderRange(0, 16).build());
    private final Setting<Integer> refillThreshold = sgChest.add(new IntSetting.Builder().name("refill-threshold")
        .description("Khi số block cần dùng còn ít hơn mức này sẽ đi lấy thêm.").defaultValue(8).range(1, 64).sliderRange(1, 64).build());
    private final Setting<Boolean> returnToBuilding = bool(sgChest, "return-to-building", "Quay lại vị trí xây sau khi lấy vật liệu.", true);

    // ---- Temp ----
    private final Setting<Boolean> tempBlocks = bool(sgTemp, "temporary-blocks", "Cho phép dùng block tạm (Stone/Glass).", false);
    private final Setting<TempBlocks.Pref> tempPref = sgTemp.add(new EnumSetting.Builder<TempBlocks.Pref>().name("preferred-block")
        .description("Block tạm ưu tiên.").defaultValue(TempBlocks.Pref.Stone).build());
    private final Setting<Boolean> tempPlacement = bool(sgTemp, "temporary-placement", "Dựng cầu/cột bằng block tạm khi Baritone không tới được vị trí xây.", true);
    private final Setting<Boolean> autoCleanup = bool(sgTemp, "auto-cleanup", "Thu hồi block tạm khi xong việc.", true);
    private final Setting<Boolean> restorePos = bool(sgTemp, "restore-original-position", "Quay về vị trí ban đầu sau khi dọn block tạm.", true);

    // ---- Water ----
    private final Setting<Boolean> autoWater = bool(sgWater, "auto-water", "Tạo nguồn nước bằng Ice ở vị trí schematic yêu cầu nước.", false);
    private final Setting<Boolean> autoCollectIce = bool(sgWater, "auto-collect-ice", "Tự lấy Ice từ rương khi thiếu.", true);
    private final Setting<Integer> icePlaceDelay = sgWater.add(new IntSetting.Builder().name("ice-placement-delay").description("Tick chờ giữa đặt Ice và phá Ice.")
        .defaultValue(5).range(0, 40).sliderRange(0, 40).build());
    private final Setting<Boolean> autoBreakIce = bool(sgWater, "auto-break-ice", "Tự phá Ice do module đặt để ra nước.", true);
    private final Setting<Boolean> waterVerify = bool(sgWater, "water-verification", "Kiểm tra vị trí đã thành nguồn nước sau khi phá.", true);

    // ---- Repair ----
    private final Setting<Boolean> autoWrongBreak = bool(sgRepair, "auto-wrong-block-break", "Tự phá block do module đặt sai so với schematic.", true);
    private final Setting<Boolean> autoPick = bool(sgRepair, "auto-pickaxe-switch", "Tự chọn công cụ phù hợp để phá.", true);
    private final Setting<PickPrio> pickPrio = sgRepair.add(new EnumSetting.Builder<PickPrio>().name("pickaxe-priority")
        .description("BestAvailable / HotbarOnly / LowestTier.").defaultValue(PickPrio.BestAvailable).build());
    private final Setting<Boolean> autoReplace = bool(sgRepair, "auto-re-place-correct-block", "Đặt lại block đúng sau khi phá.", true);
    private final Setting<Integer> repairDelay = sgRepair.add(new IntSetting.Builder().name("repair-delay").description("Tick giữa các lần sửa.")
        .defaultValue(2).range(0, 20).sliderRange(0, 20).build());
    private final Setting<Integer> repairRetry = sgRepair.add(new IntSetting.Builder().name("repair-retry").description("Số lần sửa tối đa cho mỗi vị trí.")
        .defaultValue(3).range(1, 10).sliderRange(1, 10).build());

    // ---- State ----
    private final ChestSupply supply = new ChestSupply(this::fail, this::say);
    private final TempBlocks temp = new TempBlocks();
    private final Map<BlockPos, Block> ours = new HashMap<>();          // block do module dat
    private final Map<BlockPos, int[]> pending = new HashMap<>();       // pos -> {tickDat, soLanThu}
    private final Set<BlockPos> failed = new HashSet<>();
    private final Map<BlockPos, Integer> repairCount = new HashMap<>();
    private final Map<BlockPos, Integer> iceAt = new HashMap<>();       // pos -> tick dat Ice
    private final Map<BlockPos, Integer> waterCheck = new HashMap<>();  // pos -> tick phai kiem tra nuoc
    private final Map<BlockPos, Integer> placeTries = new HashMap<>();
    private final Map<String, Integer> lastMsg = new HashMap<>();
    private int tick, delay, syncWait, navTimer, scanTimer;
    private boolean placing, builtAnnounced;
    private BlockPos navTarget, startPos;
    private boolean pillaring;

    public EasyPlace() {
        super(Categories.World, "easy-place", "Easy Place theo schematic Litematica: đúng BlockState, lấy đồ từ rương, block tạm, nước, sửa block sai.");
    }

    /**
     * Khong de Meteor danh dau module la ON neu cac dieu kien bat buoc chua san sang.
     * Meteor Module.toggle() la diem vao chung cho click GUI va keybind.
     */
    @Override
    public void toggle() {
        if (!isActive()) {
            String problem = readinessError();
            if (problem != null) {
                fail("Không thể bật EasyPlace: " + problem);
                return;
            }
        }
        super.toggle();
    }

    private String readinessError() {
        if (mc.player == null || mc.world == null) return "Bạn phải vào một thế giới trước.";
        String schematicError = Schem.error();
        if (schematicError != null) return schematicError;
        if (aura.get() && baritoneMove.get() && !Nav.available()) {
            return "Không dùng được Baritone API (" + Nav.lastError()
                + "). Kiểm tra Baritone API tương thích Minecraft 1.21.11 hoặc tắt Baritone Move.";
        }
        return null;
    }

    private Setting<Boolean> bool(SettingGroup g, String name, String desc, boolean def) {
        return g.add(new BoolSetting.Builder().name(name).description(desc).defaultValue(def).build());
    }

    // ---------- helpers ----------
    private void say(String m) { if (chatFb.get()) info("%s", m); }

    private void fail(String m) { if (chatFb.get()) error("%s", m); }

    private void throttled(String key, String msg, boolean isError) {
        Integer last = lastMsg.get(key);
        if (last != null && tick - last < 200) return;
        lastMsg.put(key, tick);
        if (isError) fail(msg); else say(msg);
    }

    private boolean fullInv() { return pickSource.get() == PickSource.FullInventory; }

    private int syncTicks() {
        if (pickSync.get() == PickSync.Instant) return 0;
        int ping = mc.getNetworkHandler() != null && mc.player != null && mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) != null
            ? mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()).getLatency() : 0;
        return Math.min(4, 1 + ping / 50);
    }

    private boolean visible(BlockPos pos) {
        Vec3d eye = mc.player.getEyePos();
        BlockHitResult r = mc.world.raycast(new RaycastContext(eye, Vec3d.ofCenter(pos), RaycastContext.ShapeType.OUTLINE,
            RaycastContext.FluidHandling.NONE, mc.player));
        return r.getType() == HitResult.Type.MISS || r.getBlockPos().equals(pos);
    }

    /** So sanh BlockState thuc te va mong muon, co ap dung luat hopper. */
    private boolean same(BlockPos pos, BlockState cur, BlockState want) {
        boolean strict = strictState.get();
        if (want.getBlock() instanceof HopperBlock && cur.getBlock() instanceof HopperBlock) {
            boolean force = hopperForce.get() && (hopperHidden.get() || visible(pos));
            if (!force) return true;
        }
        return StateUtil.matches(cur, want, strict);
    }

    private boolean isWaterSource(BlockState s) {
        return s.getBlock() == Blocks.WATER && s.getFluidState().isStill();
    }

    private boolean wantsWater(BlockState want) {
        return want != null && want.getBlock() == Blocks.WATER && want.getFluidState().isStill();
    }

    private double reach() { return Math.min(auraRange.get(), 4.5); }

    // ---------- lifecycle ----------
    @Override
    public void onActivate() {
        tick = delay = syncWait = navTimer = scanTimer = 0;
        builtAnnounced = false;
        startPos = mc.player != null ? mc.player.getBlockPos() : null;
        pending.clear(); placeTries.clear(); failed.clear(); repairCount.clear(); iceAt.clear(); waterCheck.clear(); lastMsg.clear();
        String e = Schem.error();
        if (e != null) fail(e);
        else if (aura.get() && baritoneMove.get() && !Nav.available()) fail("Không dùng được Baritone API (" + Nav.lastError() + "). Cần baritone-api-fabric 1.17.0 cho MC 1.21.11.");
    }

    @Override
    public void onDeactivate() {
        if (supply.active()) {
            say("Module bị tắt giữa quá trình lấy vật liệu, đã dừng.");
            supply.abort();
        }
        Nav.cancelOurs();
        if (temp.size() > 0) {
            int left = temp.cleanupStep();
            if (left > 0) fail("Còn " + left + " block tạm chưa thu hồi (module đã tắt). Hãy tự phá thủ công.");
        }
        pillaring = false;
        placing = false;
        if (!ours.isEmpty()) say("Module tắt: " + ours.size() + " block đã đặt được giữ nguyên.");
    }

    @Override
    public String getInfoString() {
        return supply.active() ? "chest" : (aura.get() ? "aura" : "manual");
    }

    // ---------- manual placement (khong aura) ----------
    @EventHandler
    private void onInteract(InteractBlockEvent event) {
        if (placing || aura.get() || mc.player == null || mc.world == null) return;
        ItemStack held = mc.player.getStackInHand(event.hand);
        if (!(held.getItem() instanceof BlockItem bi)) return;
        if (Schem.error() != null) return;

        BlockHitResult hr = event.result;
        ItemPlacementContext ctx = new ItemPlacementContext(mc.world, mc.player, event.hand, held, hr);
        BlockPos target = ctx.getBlockPos();
        BlockState want = Schem.wanted(target);
        if (want == null) return;                          // ngoai schematic -> vanilla
        if (want.isAir()) {
            if (schematicLock.get()) { event.setCancelled(true); throttled("lock", "Schematic Lock: vị trí " + target.toShortString() + " phải để trống.", false); }
            return;
        }
        if (schematicOnly.get() && !Schem.inside(target)) return;
        if (!allBlocks.get() && !StateUtil.isDirectional(want)) return;

        if (bi.getBlock() != want.getBlock()) {
            if (schematicLock.get()) { event.setCancelled(true); throttled("lock", "Schematic Lock: vị trí " + target.toShortString() + " cần " + want.getBlock().getName().getString(), false); }
            return;
        }
        Solver.Plan plan = Solver.solve(mc, target, want, held, s -> same(target, s, want), canRotate(), smartPlacement.get(), 4.5);
        if (plan == null) {
            if (schematicLock.get()) { event.setCancelled(true); throttled("lock", "Không có cách đặt đúng hướng tại " + target.toShortString(), true); }
            return;
        }
        event.setCancelled(true);
        execute(plan, event.hand);
        ours.put(target.toImmutable(), want.getBlock());
        pending.put(target.toImmutable(), new int[]{tick, 0});
    }

    private boolean canRotate() { return rotationSpoof.get() && direction.get() == Direction.Auto; }

    private void execute(Solver.Plan pl, Hand hand) {
        Runnable r = () -> {
            float oy = mc.player.getYaw(), op = mc.player.getPitch();
            placing = true;
            try {
                mc.player.setYaw(pl.yaw());     // de du doan phia client khop voi server
                mc.player.setPitch(pl.pitch());
                mc.interactionManager.interactBlock(mc.player, hand, new BlockHitResult(pl.hit(), pl.face(), pl.neighbor(), false));
                mc.player.swingHand(hand);
            } finally {
                mc.player.setYaw(oy);
                mc.player.setPitch(op);
                placing = false;
            }
        };
        if (rotationSpoof.get()) Rotations.rotate(pl.yaw(), pl.pitch(), 50, r);
        else r.run();
    }

    // ---------- main tick ----------
    @EventHandler
    private void onTick(TickEvent.Pre event) {
        tick++;
        if (mc.player == null || mc.world == null) return;

        // Neu schematic/Baritone bi go hoac mat sau khi bat, tu tat module thay vi
        // de giao dien tiep tuc hien ON trong khi khong the lam viec.
        if (aura.get()) {
            String problem = readinessError();
            if (problem != null) {
                fail("EasyPlace tự tắt vì không thể hoạt động: " + problem);
                disable();
                return;
            }
        }

        if (mc.currentScreen != null && !(supply.active())) { /* dang mo GUI khac: tam dung */ return; }
        verifyPending();
        if (!aura.get()) return;
        if (!mc.player.isAlive()) return;

        if (syncWait > 0) { syncWait--; return; }

        if (supply.active()) {
            supply.tick();
            status("Đang lấy vật liệu: " + (supply.item() != null ? supply.item().getName().getString() : ""));
            return;
        }
        int res = supply.consumeResult();
        if (res == -1) {
            // that bai da duoc bao trong chat; khong tiep tuc xay thieu vat lieu o vi tri do
            throttled("supply-failed", "Lấy vật liệu thất bại, tạm nghỉ 5 giây rồi thử lại.", true);
            delay = 100;
        }

        if (delay > 0) { delay--; return; }

        if (mc.player.isUsingItem()) return;

        if (repairStep()) { delay = repairDelay.get(); return; }
        if (waterStep()) return;
        if (pillarStep()) return;
        buildStep();
    }

    private void status(String s) {
        if (showStatus.get() && mc.inGameHud != null) mc.inGameHud.setOverlayMessage(Text.literal("[EasyPlace] " + s), false);
    }

    // ---------- verify (server ack) ----------
    private void verifyPending() {
        if (pending.isEmpty()) return;
        int ping = 0;
        var e = mc.getNetworkHandler() != null ? mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) : null;
        if (e != null) ping = e.getLatency();
        int timeout = 12 + ping / 50;
        List<BlockPos> done = new ArrayList<>();
        for (Map.Entry<BlockPos, int[]> en : new ArrayList<>(pending.entrySet())) {
            BlockPos pos = en.getKey();
            BlockState want = Schem.wanted(pos);
            BlockState cur = mc.world.getBlockState(pos);
            if (want != null && same(pos, cur, want)) { done.add(pos); placeTries.remove(pos); continue; }
            if (tick - en.getValue()[0] < timeout) continue;
            // qua han ma van chua khop
            if (want != null && cur.getBlock() == want.getBlock()) {
                done.add(pos); // dung block nhung sai state: de repairStep xu ly
                fail("BlockState không khớp tại " + pos.toShortString() + " (mong muốn " + want + ", thực tế " + cur + ").");
                continue;
            }
            int tries = placeTries.getOrDefault(pos, 0) + 1;
            done.add(pos);
            ours.remove(pos);
            if (tries > 3) {
                failed.add(pos.toImmutable());
                placeTries.remove(pos);
                fail("Server từ chối / không thể đặt block tại " + pos.toShortString() + " sau 3 lần thử, bỏ qua vị trí này.");
            } else {
                placeTries.put(pos.toImmutable(), tries); // se duoc dat lai trong buildStep
            }
        }
        for (BlockPos p : done) pending.remove(p);
    }

    // ---------- build ----------
    private List<BlockPos> scan(double range) {
        int r = (int) Math.ceil(range);
        BlockPos c = mc.player.getBlockPos();
        Vec3d eye = mc.player.getEyePos();
        List<BlockPos> out = new ArrayList<>();
        for (int x = -r; x <= r; x++)
            for (int y = -r; y <= r; y++)
                for (int z = -r; z <= r; z++) {
                    BlockPos p = c.add(x, y, z);
                    if (eye.distanceTo(Vec3d.ofCenter(p)) > range) continue;
                    BlockState want = Schem.wanted(p);
                    if (want == null || want.isAir()) continue;
                    out.add(p);
                }
        out.sort(Comparator.<BlockPos>comparingInt(BlockPos::getY).thenComparingDouble(p -> p.getSquaredDistance(mc.player.getX(), mc.player.getY(), mc.player.getZ())));
        return out;
    }

    private int remaining(Item item) {
        int[] b = Schem.bounds();
        if (b == null) return 0;
        int n = 0;
        BlockPos c = mc.player.getBlockPos();
        int x0 = Math.max(b[0], c.getX() - 32), x1 = Math.min(b[3], c.getX() + 32);
        int y0 = Math.max(b[1], c.getY() - 32), y1 = Math.min(b[4], c.getY() + 32);
        int z0 = Math.max(b[2], c.getZ() - 32), z1 = Math.min(b[5], c.getZ() + 32);
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = x0; x <= x1; x++) for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++) {
            m.set(x, y, z);
            BlockState w = Schem.wanted(m);
            if (w == null || w.isAir() || StateUtil.isDependentHalf(w)) continue;
            if (w.getBlock().asItem() != item) continue;
            if (!same(m, mc.world.getBlockState(m), w)) n++;
        }
        return n;
    }

    private boolean requestSupply(Item item, boolean ignoreRefillCheck) {
        if (!chestEnable.get()) return false;
        if (!Nav.available() && baritoneMove.get()) return false;
        int need = Math.max(1, remaining(item));
        BlockPos cp = chestPos.get();
        if (cp.equals(BlockPos.ORIGIN)) {
            throttled("chest-unset", "Chưa nhập tọa độ rương (Chest X/Y/Z) trong setting.", true);
            return false;
        }
        return supply.start(item, need, cp, chestRadius.get(), returnToBuilding.get(), baritoneMove.get());
    }

    private boolean buildStep() {
        int budget = depSync.get() == DepSync.Immediate && auraDelay.get() == 0 ? 3 : 1;
        boolean any = false;
        boolean anyMissing = false;
        for (BlockPos pos : scan(reach())) {
            if (budget <= 0) break;
            BlockState want = Schem.wanted(pos);
            if (want == null || want.isAir() || StateUtil.isDependentHalf(want)) continue;
            if (wantsWater(want) || want.getBlock() instanceof FluidBlock) continue; // xu ly boi Auto Water
            if (failed.contains(pos) || pending.containsKey(pos)) continue;
            BlockState cur = mc.world.getBlockState(pos);
            if (same(pos, cur, want)) continue;
            anyMissing = true;
            if (!cur.isReplaceable()) continue; // dang co block khac: repairStep lo neu la block cua ta

            Item item = want.getBlock().asItem();
            if (item == Items.AIR) {
                failed.add(pos.toImmutable());
                fail("Block " + want.getBlock().getName().getString() + " không có item để đặt, bỏ qua " + pos.toShortString());
                continue;
            }
            int have = Inv.count(item, fullInv());
            int haveAll = Inv.count(item, true);
            boolean low = autoRefill.get() && haveAll < refillThreshold.get() && haveAll < remaining(item);
            if (have == 0 || (low && haveAll == 0)) {
                if (haveAll > 0 && !fullInv()) {
                    throttled("src-" + item, "Có " + item.getName().getString() + " nhưng không nằm trong hotbar (Inventory Pick Source = VisibleOnly).", true);
                    continue;
                }
                if (requestSupply(item, false)) return true;
                throttled("miss-" + item, "Thiếu vật liệu: " + item.getName().getString() + " (cần cho " + pos.toShortString() + ")"
                    + (chestEnable.get() ? "" : ". Bật Enable Chest Supply hoặc bổ sung vào inventory."), true);
                continue;
            }
            if (low && have > 0 && haveAll < refillThreshold.get() && chestEnable.get()) {
                // dang dung het: di lay them truoc khi het hang (Auto Refill)
                if (requestSupply(item, true)) return true;
            }

            int eq = Inv.equip(item, fullInv());
            if (eq < 0) { throttled("eq-" + item, "Không đưa được " + item.getName().getString() + " lên tay.", true); continue; }
            if (eq > 0) { syncWait = syncTicks(); if (syncWait > 0) return true; }

            ItemStack stack = mc.player.getMainHandStack();
            Solver.Plan plan = Solver.solve(mc, pos, want, stack, s -> same(pos, s, want), canRotate(), smartPlacement.get(), reach());
            if (plan == null) continue; // chua co diem tua / chua dat duoc phu thuoc: thu o tick sau
            execute(plan, Hand.MAIN_HAND);
            ours.put(pos.toImmutable(), want.getBlock());
            pending.put(pos.toImmutable(), new int[]{tick, 0});
            any = true;
            budget--;
            delay = auraDelay.get();
            if (depSync.get() == DepSync.NextTick) break;
        }
        if (any) { status("Đang xây..."); return true; }

        // khong co gi dat duoc trong tam: di chuyen toi cho can xay
        if (!anyMissing) moveOrFinish();
        else if (baritoneMove.get()) moveOrFinish();
        return false;
    }

    private void moveOrFinish() {
        BlockPos next = nextMissing();
        if (next == null) {
            navTarget = null;
            if (!builtAnnounced && ours.size() > 0 && pending.isEmpty()) {
                builtAnnounced = true;
                say("Hoàn thành schematic trong vùng quét (" + ours.size() + " block đã đặt).");
            }
            if (autoCleanup.get() && temp.size() > 0) {
                int left = temp.cleanupStep();
                status("Thu hồi block tạm: còn " + left);
                if (left == 0 && restorePos.get() && startPos != null && baritoneMove.get()
                    && mc.player.getBlockPos().getSquaredDistance(startPos) > 4) Nav.goNear(startPos, 1);
            } else if (temp.size() == 0 && restorePos.get() && startPos != null && baritoneMove.get()
                && builtAnnounced && mc.player.getBlockPos().getSquaredDistance(startPos) > 16 && !Nav.isPathing()) {
                Nav.goNear(startPos, 1);
            }
            return;
        }
        builtAnnounced = false;
        if (!baritoneMove.get()) { status("Chờ: cần tới gần " + next.toShortString()); return; }
        status("Di chuyển tới " + next.toShortString());
        double d = mc.player.getEyePos().distanceTo(Vec3d.ofCenter(next));
        if (!next.equals(navTarget)) { navTarget = next; navTimer = 0; }
        navTimer++;
        if (d <= reach()) return;
        if (Nav.busyWithOther()) { throttled("nav-busy", "Baritone đang làm việc khác, không tranh quyền điều khiển.", true); return; }
        if (!Nav.isPathing() && (navTimer == 1 || navTimer % 60 == 0)) {
            if (!Nav.goNear(next, Math.max(1, (int) reach() - 1))) {
                throttled("nav-fail", "Không điều khiển được Baritone: " + Nav.lastError(), true);
            }
        }
        if (navTimer > 80 && !Nav.isPathing()) {
            // Baritone khong tim duoc duong
            if (tempBlocks.get() && tempPlacement.get() && scaffoldToward(next)) return;
            failed.add(next.toImmutable());
            navTarget = null;
            fail("Baritone không tìm được đường tới " + next.toShortString() + (tempBlocks.get() ? " và không thể dựng block tạm." : ". Bật Temporary Blocks để dựng cầu/cột."));
        }
    }

    private BlockPos nextMissing() {
        int[] b = Schem.bounds();
        if (b == null) return null;
        scanTimer++;
        BlockPos c = mc.player.getBlockPos();
        int R = 48;
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = Math.max(b[0], c.getX() - R); x <= Math.min(b[3], c.getX() + R); x++)
            for (int y = Math.max(b[1], c.getY() - R); y <= Math.min(b[4], c.getY() + R); y++)
                for (int z = Math.max(b[2], c.getZ() - R); z <= Math.min(b[5], c.getZ() + R); z++) {
                    m.set(x, y, z);
                    BlockState w = Schem.wanted(m);
                    if (w == null || w.isAir() || StateUtil.isDependentHalf(w) || wantsWater(w)) continue;
                    if (failed.contains(m)) continue;
                    BlockState cur = mc.world.getBlockState(m);
                    if (same(m, cur, w) || !cur.isReplaceable()) continue;
                    Item it = w.getBlock().asItem();
                    if (it == Items.AIR || Inv.count(it, fullInv()) == 0 && !chestEnable.get()) continue;
                    double d = m.getSquaredDistance(c);
                    if (d < bestD) { bestD = d; best = m.toImmutable(); }
                }
        return best;
    }

    // ---------- temporary blocks ----------
    private boolean scaffoldToward(BlockPos target) {
        Item item = temp.pick(tempPref.get(), fullInv());
        if (item == null) {
            Item pref = temp.preferred(tempPref.get());
            if (chestEnable.get() && requestSupply(pref, true)) return true;
            throttled("temp-none", "Không có Stone/Glass để dựng block tạm" + (chestEnable.get() ? " (rương cũng không có)." : "."), true);
            return false;
        }
        int eq = Inv.equip(item, fullInv());
        if (eq < 0) return false;
        if (eq > 0) { syncWait = syncTicks(); return true; }
        Vec3d p = mc.player.getPos();
        if (target.getY() > p.y + 3) { pillaring = true; navTarget = target; return true; }
        BlockPos step = temp.bridgeStep(target);
        if (step == null) { throttled("temp-bad", "Không có vị trí hợp lệ để đặt block tạm (sẽ đè lên schematic/block có sẵn).", true); return false; }
        if (temp.place(step, item)) {
            Nav.goNear(step.up(), 0);
            navTimer = 0;
            return true;
        }
        return false;
    }

    private boolean pillarStep() {
        if (!pillaring) return false;
        BlockPos target = navTarget;
        if (target == null || mc.player.getEyePos().distanceTo(Vec3d.ofCenter(target)) <= reach() || !tempBlocks.get()) {
            pillaring = false;
            return false;
        }
        Item item = temp.pick(tempPref.get(), fullInv());
        if (item == null) { pillaring = false; fail("Hết block tạm khi dựng cột."); return false; }
        if (!Inv.holding(item)) {
            int eq = Inv.equip(item, fullInv());
            if (eq < 0) { pillaring = false; return false; }
            syncWait = syncTicks();
            return true;
        }
        if (mc.player.isOnGround()) { Vec3d v = mc.player.getVelocity(); mc.player.setVelocity(v.x, 0.42, v.z); return true; }
        BlockPos spot = temp.pillarSpot();
        if (spot != null && mc.player.getY() - spot.getY() >= 1.05 && mc.player.getVelocity().y <= 0.3) temp.place(spot, item);
        return true;
    }

    // ---------- repair ----------
    private boolean repairStep() {
        if (!autoWrongBreak.get() || ours.isEmpty()) return false;
        Vec3d eye = mc.player.getEyePos();
        for (Map.Entry<BlockPos, Block> en : new ArrayList<>(ours.entrySet())) {
            BlockPos pos = en.getKey();
            BlockState want = Schem.wanted(pos);
            if (want == null || want.isAir()) continue;               // khong xac dinh duoc schematic -> khong dung vao
            if (!Schem.inside(pos)) continue;                         // ngoai vung xay dung
            if (pending.containsKey(pos)) continue;
            BlockState cur = mc.world.getBlockState(pos);
            if (cur.isAir() || cur.isReplaceable()) continue;
            if (same(pos, cur, want)) { repairCount.remove(pos); continue; }
            if (cur.getBlock() != en.getValue()) { ours.remove(pos); continue; } // nguoi choi doi block: khong phai cua ta
            if (eye.distanceTo(Vec3d.ofCenter(pos)) > 4.5) continue;
            int tries = repairCount.getOrDefault(pos, 0);
            if (tries >= repairRetry.get()) {
                if (failed.add(pos.toImmutable())) fail("Sửa block thất bại sau " + tries + " lần tại " + pos.toShortString() + ": " + cur + " ≠ " + want);
                ours.remove(pos);
                continue;
            }
            if (!BlockUtils.canBreak(pos, cur)) {
                if (failed.add(pos.toImmutable())) fail("Không thể phá block sai tại " + pos.toShortString());
                continue;
            }
            if (autoPick.get()) {
                int m = switch (pickPrio.get()) { case BestAvailable -> 0; case HotbarOnly -> 1; case LowestTier -> 2; };
                int r = Inv.equipTool(cur, m, false);
                if (r > 0) { syncWait = syncTicks(); return true; }
            }
            BlockUtils.breakBlock(pos, true);
            if (mc.world.getBlockState(pos).isAir()) {
                repairCount.put(pos.toImmutable(), tries + 1);
                ours.remove(pos);
                if (!autoReplace.get()) failed.add(pos.toImmutable());
                else say("Đã phá block sai tại " + pos.toShortString() + ", sẽ đặt lại đúng schematic.");
            }
            return true;
        }
        return false;
    }

    // ---------- water ----------
    private boolean waterStep() {
        if (!autoWater.get()) return false;
        Vec3d eye = mc.player.getEyePos();
        double range = reach();
        int r = (int) Math.ceil(range);
        BlockPos c = mc.player.getBlockPos();
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            BlockPos pos = c.add(x, y, z);
            if (eye.distanceTo(Vec3d.ofCenter(pos)) > range) continue;
            BlockState want = Schem.wanted(pos);
            if (!wantsWater(want) || failed.contains(pos)) continue;
            BlockState cur = mc.world.getBlockState(pos);

            Integer chk = waterCheck.get(pos);
            if (chk != null) {                                   // dang cho kiem tra nuoc sau khi pha Ice
                if (isWaterSource(cur)) { waterCheck.remove(pos); iceAt.remove(pos); say("Đã tạo nguồn nước tại " + pos.toShortString()); continue; }
                if (tick >= chk) {
                    waterCheck.remove(pos);
                    iceAt.remove(pos);
                    failed.add(pos.toImmutable());
                    fail("Ice không tạo được nước tại " + pos.toShortString() + " (server không cho / block bên dưới không đỡ / Nether / creative / dụng cụ Silk Touch).");
                }
                return true;
            }
            if (isWaterSource(cur)) continue;

            if (cur.getBlock() == Blocks.ICE && iceAt.containsKey(pos)) {   // chi pha Ice do ta dat, loai thuong
                if (!autoBreakIce.get()) continue;
                if (tick - iceAt.get(pos) < icePlaceDelay.get()) return true;
                if (!BlockUtils.canBreak(pos, cur)) { failed.add(pos.toImmutable()); fail("Không thể phá Ice tại " + pos.toShortString()); return true; }
                int sw = Inv.equipTool(cur, 0, true);   // dung cong cu KHONG silk touch
                if (sw > 0) { syncWait = syncTicks(); return true; }
                BlockUtils.breakBlock(pos, true);
                if (mc.world.getBlockState(pos).getBlock() != Blocks.ICE) {
                    if (waterVerify.get()) waterCheck.put(pos.toImmutable(), tick + 20);
                    else iceAt.remove(pos);
                }
                return true;
            }
            if (cur.getBlock() == Blocks.ICE || cur.getBlock() == Blocks.PACKED_ICE || cur.getBlock() == Blocks.BLUE_ICE
                || cur.getBlock() == Blocks.FROSTED_ICE) {
                continue; // Ice co san cua nguoi choi / loai khac: khong dung vao
            }
            if (!cur.isReplaceable()) continue;

            // dieu kien moi truong de Ice -> nuoc
            String why = null;
            GameMode gm = mc.interactionManager.getCurrentGameMode();
            if (mc.world.getDimension().ultrawarm()) why = "Nether (ultrawarm) làm Ice biến mất không tạo nước";
            else if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) why = "chế độ " + gm + " phá Ice không tạo nước";
            else {
                BlockState below = mc.world.getBlockState(pos.down());
                boolean support = below.blocksMovement() || !below.getFluidState().isEmpty();
                if (!support) why = "block bên dưới không đỡ được (Ice cần block cứng hoặc chất lỏng bên dưới)";
            }
            if (why != null) { failed.add(pos.toImmutable()); fail("Không thể tạo nước tại " + pos.toShortString() + ": " + why + "."); return true; }

            if (Inv.count(Items.ICE, fullInv()) == 0) {
                if (Inv.count(Items.ICE, true) > 0) { throttled("ice-src", "Có Ice nhưng không ở hotbar (Inventory Pick Source = VisibleOnly).", true); return true; }
                if (autoCollectIce.get() && requestSupply(Items.ICE, true)) return true;
                throttled("ice-miss", "Thiếu Ice để tạo nước tại " + pos.toShortString() + ".", true);
                return true;
            }
            int eq = Inv.equip(Items.ICE, fullInv());
            if (eq > 0) { syncWait = syncTicks(); return true; }
            if (eq < 0) return true;
            if (BlockUtils.place(pos, InvUtils.findInHotbar(Items.ICE), true, 45)) {
                iceAt.put(pos.toImmutable(), tick);
                delay = icePlaceDelay.get();
            } else {
                throttled("ice-place-" + pos, "Không đặt được Ice tại " + pos.toShortString() + " (không có điểm tựa?).", true);
            }
            return true;
        }
        return false;
    }
}
