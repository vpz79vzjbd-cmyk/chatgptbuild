package dev.autobuilder;

import dev.autobuilder.modules.EasyPlace;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;

import java.lang.invoke.MethodHandles;

public class AutoBuilderAddon extends MeteorAddon {
    @Override
    public void onInitialize() {
        // Bat buoc de Orbit (@EventHandler) hoat dong trong package cua addon
        MeteorClient.EVENT_BUS.registerLambdaFactory("dev.autobuilder",
            (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));
        Modules.get().add(new EasyPlace());
    }

    @Override
    public void onRegisterCategories() {}

    @Override
    public String getPackage() {
        return "dev.autobuilder";
    }
}
