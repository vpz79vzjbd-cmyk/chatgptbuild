# Build AutoBuilder Addon with GitHub Actions

The workflow is already at `.github/workflows/build.yml` at the project root.

1. Put the **contents of this project** (including `.github/` and `libs/`) at the root of a GitHub repository.
2. Open the repository's **Actions** tab.
3. Run **Build AutoBuilder Addon**, or push a commit to trigger it.
4. Wait for a completed green run.
5. Download the `autobuilder-addon-1.0.0` artifact. Use the remapped JAR without the `-dev` suffix if Loom produces both variants.

The workflow provisions Java 21 and Gradle 9.7.1, validates all four supplied library JARs, runs `gradle clean build`, verifies that the resulting mod JAR contains both `fabric.mod.json` and the `AutoBuilderAddon` entrypoint, and uploads the result.

A failed or cancelled workflow does not produce a verified JAR. Inspect the build log and fix the reported compile/dependency issue before treating it as complete.
